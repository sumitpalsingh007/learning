1) Import the IntergallacticLanguageTransalator as a Java application in Ecplise.
2) Plcae the input you want to test in the /IntergallacticLanguageTransalator/src/com/thoughtworks/india/launch/inputFile.txt file.
3) Run the /IntergallacticLanguageTransalator/src/com/thoughtworks/india/launch/LaunchApplication.java file as a Java Application to view the result.
4) If you run the Junits you might get popup asking for JUnit running configuration settings. Select Eclipse Junit Runner.
