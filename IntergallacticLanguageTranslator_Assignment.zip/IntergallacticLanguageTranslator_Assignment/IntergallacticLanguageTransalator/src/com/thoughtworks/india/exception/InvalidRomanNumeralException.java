/**
 * 
 */
package com.thoughtworks.india.exception;

/**
 * @author SUMIT
 *
 */
public class InvalidRomanNumeralException extends Exception {

	public InvalidRomanNumeralException(String s) {
		super(s);
	}

}
