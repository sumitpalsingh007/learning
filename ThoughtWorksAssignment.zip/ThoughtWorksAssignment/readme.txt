1) Import the ThoughtWorksAssignment as a java project in Eclipse IDE
2) Build the project with java 1.7
3) Run TestApplication.java as a Java Application
4) See the input and output at Console



Explanation:

This code is based on logic of checking if existing tracks can accomodate the current talk; if yes the add the talk in the existing
track otherwise create a new track and add the talk.