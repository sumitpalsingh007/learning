/**
 * 
 */
package com.thoughtworks.india.exception;

/**
 * @author SUMIT
 *
 */
public class InvalidCommodityException extends Exception {

	public InvalidCommodityException(String s) {
		super(s);
	}

}
