Design Explanation:-

I have taken Roman Numbers as constanst(ENUM) which contains all their rules related to repetetion and substraction.
I have created Util classes for all the implementation logic.
For running the application I have used a class which loads all the util classes from static context and then reads and process inputs from a text file.



Instructions to run the code:-

1) Import the IntergallacticLanguageTransalator as a Java application in Ecplise.
2) Plcae the input you want to test in the /IntergallacticLanguageTransalator/src/com/thoughtworks/india/launch/inputFile.txt file.
3) Run the /IntergallacticLanguageTransalator/src/com/thoughtworks/india/launch/LaunchApplication.java file as a Java Application to view the result.
4) If you run the Junits you might get popup asking for JUnit running configuration settings. Select Eclipse Junit Runner.
