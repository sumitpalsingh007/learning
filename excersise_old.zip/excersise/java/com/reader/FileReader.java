package com.reader;

public interface FileReader {

	void readFile(String fileName);
}
