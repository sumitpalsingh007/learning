package com.dictionary;

import java.io.File;

import com.reader.FileReader;

public class Dictionary {
		
	File dataSourceFile;
	String fileName;
	FileReader fileReader;
	
	public Dictionary(FileReader reader){
		fileReader=reader;
	}
	
	public void launch(){
		
	}

}
